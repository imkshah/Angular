import React, {Component} from 'react'
import PropTypes from 'prop-types'
import {withStyles} from 'material-ui/styles'
import Card, {CardContent, CardMedia} from 'material-ui/Card'
import Typography from 'material-ui/Typography'

import back from './../assets/images/img.png'

import Grid from 'material-ui/Grid'
import auth from './../auth/auth-helper'
import FindPeople from './../user/FindPeople'
import Newsfeed from './../post/Newsfeed'
import styled from 'styled-components'


const H1 = styled.h1`

color:black`;
const Div = styled.div`
background-color:skyblue`;
const Div1 = styled.div`
background-color:skyblue;
border-radius: 25px;
text-align:center;
box-shadow: 5px 10px #000;`;
const styles = theme => ({
  root: {
    flexGrow: 1,
    margin: 30,
  },
  card: {
    maxWidth: '1500',
    minHeight: '1400',
    
    
  },
  title: {
  
    color: theme.palette.text.danger
  },
  media: {
    minHeight: 400
  }
})

class Home extends Component {
  state = {
    defaultPage: true
  }
  init = () => {
    if(auth.isAuthenticated()){
      this.setState({defaultPage: false})
    }else{
      this.setState({defaultPage: true})
    }
  }
  componentWillReceiveProps = () => {
    this.init()
  }
  componentDidMount = () => {
    this.init()
  }
  render() {
   
    const {classes} = this.props
    return (
      <Div>
      <div  className={classes.root}>
        {this.state.defaultPage &&
          <Grid container spacing={24}>
          <Typography  type="headline" component="h1" className={classes.title}>
                  <H1>Find your dream job here...</H1>
                </Typography>
            <Grid item xs={12}>
              <Card className={classes.card}>
                
                <CardMedia className={classes.media} image={back} title="Unicorn Shells"/>
                <CardContent>
                  <Typography type="body1" component="p">
                   
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        }
        {!this.state.defaultPage &&
          <Grid container spacing={24}>
            <Grid item xs={8} sm={7}>
              <Newsfeed/>
            </Grid>
            <Grid item xs={6} sm={5}>
              <FindPeople/>
            </Grid>
          </Grid>
        }
        <Div1><div>BlinkedIn corp © 2018</div></Div1>
      </div>
      
      </Div>
      
    )
  }
}

Home.propTypes = {
  classes: PropTypes.object.isRequired
}

export default withStyles(styles)(Home)
